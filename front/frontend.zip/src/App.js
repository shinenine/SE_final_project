import SearchPage from "./page/searchPage";
import './App.css';

function App() {
  return (
    <div className="App">
        <SearchPage />
    </div>
  );
}

export default App;
